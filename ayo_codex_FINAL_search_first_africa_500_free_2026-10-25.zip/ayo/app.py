"""Ayo alpha: real accounts, Shopify merchant OAuth, live read-only sync.

Not production-hardened: email verification, billing, queued sync, distributed rate
limits, compliance review, migrations, monitoring and third-party audits remain.
"""
import base64
import hashlib
import hmac
import json
import os
import re
import secrets
import time
from collections import defaultdict
from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation
from pathlib import Path
from urllib.parse import urlencode

import httpx
from cryptography.fernet import Fernet
from fastapi import Depends, FastAPI, Form, HTTPException, Request
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from jinja2 import Environment, FileSystemLoader, select_autoescape
from sqlalchemy import Column, Float, ForeignKey, Integer, String, Text, create_engine, select
from sqlalchemy.orm import Session, declarative_base, sessionmaker
from starlette.middleware.sessions import SessionMiddleware

ROOT = Path(__file__).resolve().parent.parent
ENV = os.getenv('ENVIRONMENT', 'development')
ORIGIN = os.getenv('APP_ORIGIN', 'http://localhost:8000').rstrip('/')
SHOPIFY_ID = os.getenv('SHOPIFY_CLIENT_ID', '')
SHOPIFY_SECRET = os.getenv('SHOPIFY_CLIENT_SECRET', '')
SHOPIFY_API_VERSION = os.getenv('SHOPIFY_API_VERSION', '2026-10')
SCOPES = 'read_products,read_orders'
DATABASE_URL = os.getenv('DATABASE_URL', f'sqlite:///{ROOT / "ayo.db"}')
SESSION_SECRET = os.getenv('SESSION_SECRET', '')
ENCRYPTION_KEY = os.getenv('TOKEN_ENCRYPTION_KEY', '')
if ENV == 'production':
    if not ORIGIN.startswith('https://'):
        raise RuntimeError('APP_ORIGIN must use HTTPS in production')
    if len(SESSION_SECRET) < 32 or not ENCRYPTION_KEY or 'REPLACE_' in ENCRYPTION_KEY:
        raise RuntimeError('Missing production session secret / Fernet key')
    if DATABASE_URL.startswith('sqlite:'):
        raise RuntimeError('SQLite is not supported for production deployment')
if not SESSION_SECRET:
    if ENV != 'test':
        print('WARNING: ephemeral session signing key; set SESSION_SECRET before real use.')
    SESSION_SECRET = secrets.token_urlsafe(48)
if not ENCRYPTION_KEY:
    if ENV != 'test':
        print('WARNING: ephemeral encryption key; set TOKEN_ENCRYPTION_KEY before real use.')
    ENCRYPTION_KEY = Fernet.generate_key().decode()
fernet = Fernet(ENCRYPTION_KEY.encode())

engine = create_engine(DATABASE_URL, connect_args={'check_same_thread': False} if DATABASE_URL.startswith('sqlite:') else {}, pool_pre_ping=True)
DbSession = sessionmaker(bind=engine, expire_on_commit=False)
Base = declarative_base()


class User(Base):
    __tablename__ = 'users'
    id = Column(Integer, primary_key=True)
    email = Column(String(320), unique=True, nullable=False, index=True)
    password_hash = Column(String(300), nullable=False)
    joined = Column(Float, default=time.time, nullable=False)


class Shop(Base):
    __tablename__ = 'shops'
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey('users.id'), nullable=False, unique=True, index=True)
    domain = Column(String(255), unique=True, nullable=False)
    token_cipher = Column(Text, nullable=False)
    refresh_cipher = Column(Text, nullable=True)
    token_expires_at = Column(Float, nullable=True)
    refresh_expires_at = Column(Float, nullable=True)
    linked_at = Column(Float, default=time.time)
    granted_scopes = Column(Text, nullable=False, default='')


class Snapshot(Base):
    __tablename__ = 'snapshots'
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey('users.id'), nullable=False, unique=True, index=True)
    domain = Column(String(255), nullable=False)
    currency = Column(String(10), nullable=False)
    shop_name = Column(String(255), nullable=False)
    product_count = Column(Integer, nullable=False)
    paid_order_count = Column(Integer, nullable=False)
    paid_order_value_minor = Column(Integer, nullable=False)
    paid_order_days = Column(Text, nullable=False)
    products_json = Column(Text, nullable=False)
    orders_limited = Column(Integer, nullable=False)
    products_limited = Column(Integer, nullable=False)
    synced_at = Column(Float, nullable=False)


Base.metadata.create_all(engine)
app = FastAPI(title='Ayo — Real Merchant Alpha', docs_url=None if ENV == 'production' else '/api-docs')
app.add_middleware(SessionMiddleware, secret_key=SESSION_SECRET, session_cookie='ayo_session', max_age=60*60*24*7, same_site='lax', https_only=ORIGIN.startswith('https://'))
app.mount('/static', StaticFiles(directory=str(ROOT / 'static')), name='static')
TEMPLATE = Environment(loader=FileSystemLoader(str(ROOT / 'templates')), autoescape=select_autoescape(['html']))


@app.middleware('http')
async def security_headers(request: Request, call_next):
    response = await call_next(request)
    response.headers['X-Content-Type-Options'] = 'nosniff'
    response.headers['Referrer-Policy'] = 'strict-origin-when-cross-origin'
    response.headers['X-Frame-Options'] = 'DENY'
    response.headers['Content-Security-Policy'] = "default-src 'self'; base-uri 'self'; object-src 'none'; frame-ancestors 'none'; form-action 'self'; img-src 'self' data:; style-src 'self'"
    if ORIGIN.startswith('https://'):
        response.headers['Strict-Transport-Security'] = 'max-age=31536000; includeSubDomains'
    return response


def db():
    with DbSession() as sess:
        yield sess


def render(request, name, **context):
    if 'csrf' not in request.session:
        request.session['csrf'] = secrets.token_urlsafe(32)
    return HTMLResponse(TEMPLATE.get_template(name).render(request=request, csrf=request.session['csrf'], **context))


def form_guard(request: Request, csrf: str):
    if not secrets.compare_digest(csrf, request.session.get('csrf', '')):
        raise HTTPException(403, 'Invalid request verification')
    # CSRF token is sufficient, and origin checked for browsers that send it.
    origin = request.headers.get('origin')
    if origin and origin.rstrip('/') != ORIGIN:
        raise HTTPException(403, 'Incorrect origin')


def password_hash(password):
    salt = secrets.token_bytes(16)
    digest = hashlib.scrypt(password.encode(), salt=salt, n=2**14, r=8, p=1)
    return 'scrypt$' + salt.hex() + '$' + digest.hex()


def password_verify(password, encoded):
    try:
        _, salt, encoded_digest = encoded.split('$')
        digest = hashlib.scrypt(password.encode(), salt=bytes.fromhex(salt), n=2**14, r=8, p=1)
        return secrets.compare_digest(digest, bytes.fromhex(encoded_digest))
    except (ValueError, TypeError):
        return False


def session_user(request, sess):
    uid = request.session.get('uid')
    if not isinstance(uid, int):
        return None
    return sess.get(User, uid)


def must_user(request, sess):
    user = session_user(request, sess)
    if not user:
        raise HTTPException(401, 'Sign in required')
    return user


def shop_domain(shop: str):
    shop = shop.strip().lower()
    # STRICT allowlist prevents token exchange SSRF / user-supplied host injection.
    if not re.fullmatch(r'[a-z0-9][a-z0-9-]{2,62}\.myshopify\.com', shop):
        raise HTTPException(400, 'Enter a valid .myshopify.com store domain')
    return shop


def oauth_valid(params):
    supplied = params.get('hmac', '')
    if not isinstance(supplied, str) or not re.fullmatch(r'[0-9a-fA-F]{64}', supplied):
        return False
    signed = '&'.join(f'{k}={v}' for k, v in sorted(params.items()) if k not in ('hmac', 'signature'))
    expected = hmac.new(SHOPIFY_SECRET.encode(), signed.encode(), hashlib.sha256).hexdigest()
    return hmac.compare_digest(supplied.lower(), expected)


def webhook_valid(body: bytes, signature: str):
    if not SHOPIFY_SECRET or not signature:
        return False
    digest = base64.b64encode(hmac.new(SHOPIFY_SECRET.encode(), body, hashlib.sha256).digest()).decode()
    return hmac.compare_digest(digest, signature)


@app.get('/', response_class=HTMLResponse)
def landing(request: Request, sess: Session = Depends(db)):
    if session_user(request, sess):
        return RedirectResponse('/dashboard', 303)
    return render(request, 'landing.html')


@app.get('/signup', response_class=HTMLResponse)
def signup_page(request: Request):
    return render(request, 'auth.html', mode='signup')


@app.post('/signup')
def signup(request: Request, email: str = Form(...), password: str = Form(...), csrf: str = Form(...), sess: Session = Depends(db)):
    form_guard(request, csrf)
    email = email.strip().lower()
    if not re.fullmatch(r'[^@\s]+@[^@\s]+\.[^@\s]+', email) or len(email) > 320:
        return render(request, 'auth.html', mode='signup', error='Enter a valid email')
    if len(password) < 12 or len(password) > 200:
        return render(request, 'auth.html', mode='signup', error='Use a password between 12 and 200 characters')
    if sess.scalar(select(User).where(User.email == email)):
        return render(request, 'auth.html', mode='signup', error='An account already exists with that email')
    new = User(email=email, password_hash=password_hash(password))
    sess.add(new)
    try:
        sess.commit()
    except Exception:
        sess.rollback()
        return render(request, 'auth.html', mode='signup', error='Unable to register this account')
    request.session.clear()
    request.session['uid'] = new.id
    request.session['csrf'] = secrets.token_urlsafe(32)
    return RedirectResponse('/dashboard', 303)


@app.get('/login', response_class=HTMLResponse)
def login_page(request: Request):
    return render(request, 'auth.html', mode='login')


@app.post('/login')
def login(request: Request, email: str = Form(...), password: str = Form(...), csrf: str = Form(...), sess: Session = Depends(db)):
    form_guard(request, csrf)
    user = sess.scalar(select(User).where(User.email == email.strip().lower()))
    if not user or not password_verify(password, user.password_hash):
        return render(request, 'auth.html', mode='login', error='Invalid email or password')
    request.session.clear()
    request.session['uid'] = user.id
    request.session['csrf'] = secrets.token_urlsafe(32)
    return RedirectResponse('/dashboard', 303)


@app.post('/logout')
def logout(request: Request, csrf: str = Form(...)):
    form_guard(request, csrf)
    request.session.clear()
    return RedirectResponse('/', 303)


@app.get('/dashboard', response_class=HTMLResponse)
def dashboard(request: Request, sess: Session = Depends(db)):
    user = session_user(request, sess)
    if not user:
        return RedirectResponse('/login', 303)
    sh = sess.scalar(select(Shop).where(Shop.user_id == user.id))
    snapshot = sess.scalar(select(Snapshot).where(Snapshot.user_id == user.id))
    data = None
    if snapshot and sh and snapshot.domain == sh.domain:
        data = {'name': snapshot.shop_name,
                'currency': snapshot.currency,
                'product_count': snapshot.product_count,
                'paid_order_count': snapshot.paid_order_count,
                'paid_order_value': f'{Decimal(snapshot.paid_order_value_minor)/100:,.2f}',
                'daily': json.loads(snapshot.paid_order_days),
                'products': json.loads(snapshot.products_json),
                'synced_at': datetime.fromtimestamp(snapshot.synced_at, timezone.utc).strftime('%Y-%m-%d %H:%M UTC'),
                'limited': bool(snapshot.orders_limited or snapshot.products_limited)}
    insight = request.session.pop('insight', None)
    return render(request, 'dashboard.html', user=user, shop=sh, data=data, insight=insight, shopify_available=bool(SHOPIFY_ID and SHOPIFY_SECRET))


@app.post('/shopify/connect')
def shopify_connect(request: Request, shop: str = Form(...), csrf: str = Form(...), sess: Session = Depends(db)):
    user = must_user(request, sess)
    form_guard(request, csrf)
    if not SHOPIFY_ID or not SHOPIFY_SECRET:
        raise HTTPException(503, 'Shopify credentials not yet configured on Ayo server')
    domain = shop_domain(shop)
    existing = sess.scalar(select(Shop).where(Shop.domain == domain))
    if existing and existing.user_id != user.id:
        raise HTTPException(409, 'Store already linked to another account')
    state = secrets.token_urlsafe(32)
    request.session['oauth_state'] = state
    request.session['oauth_shop'] = domain
    request.session['oauth_started'] = int(time.time())
    redirect_uri = f'{ORIGIN}/shopify/callback'
    params = urlencode({'client_id': SHOPIFY_ID, 'scope': SCOPES, 'redirect_uri': redirect_uri, 'state': state})
    return RedirectResponse(f'https://{domain}/admin/oauth/authorize?{params}', 303)


@app.get('/shopify/callback')
async def shopify_callback(request: Request, sess: Session = Depends(db)):
    user = must_user(request, sess)
    if not SHOPIFY_ID or not SHOPIFY_SECRET:
        raise HTTPException(503, 'Shopify credentials missing')
    params = dict(request.query_params)
    shop = shop_domain(params.get('shop', ''))
    if not oauth_valid(params):
        raise HTTPException(403, 'Invalid Shopify signature')
    try:
        stamp = int(params.get('timestamp', '0'))
    except ValueError:
        raise HTTPException(400, 'Invalid Shopify timestamp')
    if abs(time.time() - stamp) > 300:
        raise HTTPException(403, 'Expired Shopify authorization response')
    state = request.session.pop('oauth_state', '')
    session_shop = request.session.pop('oauth_shop', '')
    started = request.session.pop('oauth_started', 0)
    if not state or not secrets.compare_digest(state, params.get('state', '')) or session_shop != shop or time.time() - started > 600:
        raise HTTPException(403, 'Shopify authorization state expired or mismatched')
    code = params.get('code')
    if not code:
        raise HTTPException(400, 'Shopify authorization was not completed')
    existing = sess.scalar(select(Shop).where(Shop.domain == shop))
    if existing and existing.user_id != user.id:
        raise HTTPException(409, 'Store linked to another account')
    async with httpx.AsyncClient(timeout=20.0) as client:
        resp = await client.post(f'https://{shop}/admin/oauth/access_token', data={
            'client_id': SHOPIFY_ID, 'client_secret': SHOPIFY_SECRET, 'code': code, 'expiring': '1'},
            headers={'Accept': 'application/json'})
    if resp.status_code != 200:
        raise HTTPException(502, 'Shopify rejected access token exchange')
    body = resp.json()
    granted = set(str(body.get('scope', '')).split(','))
    if not set(SCOPES.split(',')).issubset(granted):
        raise HTTPException(403, 'Shopify did not grant all required read-only permissions')
    if not body.get('access_token') or not body.get('refresh_token'):
        raise HTTPException(502, 'Expiring offline Shopify token not provided')
    now = time.time()
    row = existing or Shop(user_id=user.id, domain=shop)
    row.user_id = user.id
    row.token_cipher = fernet.encrypt(body['access_token'].encode()).decode()
    row.refresh_cipher = fernet.encrypt(body['refresh_token'].encode()).decode()
    row.token_expires_at = now + int(body.get('expires_in', 3600))
    row.refresh_expires_at = now + int(body.get('refresh_token_expires_in', 7776000))
    row.granted_scopes = body.get('scope', '')
    sess.add(row)
    sess.commit()
    return RedirectResponse('/dashboard?connected=1', 303)


async def fresh_token(sh: Shop, sess: Session):
    now = time.time()
    if sh.token_expires_at and sh.token_expires_at > now + 120:
        return fernet.decrypt(sh.token_cipher.encode()).decode()
    if not sh.refresh_cipher or (sh.refresh_expires_at and sh.refresh_expires_at < now):
        raise HTTPException(403, 'Shopify authentication expired. Reconnect the store.')
    async with httpx.AsyncClient(timeout=20.0) as client:
        resp = await client.post(f'https://{sh.domain}/admin/oauth/access_token', data={
            'client_id': SHOPIFY_ID, 'client_secret': SHOPIFY_SECRET,
            'grant_type': 'refresh_token',
            'refresh_token': fernet.decrypt(sh.refresh_cipher.encode()).decode()},
            headers={'Accept': 'application/json'})
    if resp.status_code != 200:
        raise HTTPException(502, 'Unable to refresh Shopify authorization. Reconnect the store.')
    body = resp.json()
    if not body.get('access_token') or not body.get('refresh_token'):
        raise HTTPException(502, 'Shopify token rotation response incomplete')
    sh.token_cipher = fernet.encrypt(body['access_token'].encode()).decode()
    sh.refresh_cipher = fernet.encrypt(body['refresh_token'].encode()).decode()
    sh.token_expires_at = now + int(body.get('expires_in', 3600))
    sh.refresh_expires_at = now + int(body.get('refresh_token_expires_in', 7776000))
    sess.add(sh)
    sess.commit()
    return body['access_token']


async def gql(shop: str, token: str, query: str, variables: dict | None = None):
    async with httpx.AsyncClient(timeout=35.0) as client:
        resp = await client.post(f'https://{shop}/admin/api/{SHOPIFY_API_VERSION}/graphql.json',
                                 json={'query': query, 'variables': variables or {}},
                                 headers={'X-Shopify-Access-Token': token, 'Content-Type': 'application/json'})
    if resp.status_code == 401:
        raise HTTPException(403, 'Shopify access revoked. Reconnect this store.')
    if resp.status_code != 200:
        raise HTTPException(502, f'Shopify API failed (HTTP {resp.status_code}).')
    body = resp.json()
    if body.get('errors'):
        # Do not leak external details or protected fields into browser responses.
        raise HTTPException(502, 'Shopify rejected the data query. Check scopes and protected-data approval.')
    return body.get('data', {})


SHOP_QUERY = 'query { shop { name currencyCode } }'
PRODUCT_QUERY = '''query($cursor:String) { products(first:75, after:$cursor) {
 nodes { id title status totalInventory }
 pageInfo { hasNextPage endCursor }
}}'''
ORDERS_QUERY = '''query($cursor:String) { orders(first:75, after:$cursor, sortKey:CREATED_AT, reverse:true) {
 nodes { id processedAt cancelledAt displayFinancialStatus currentTotalPriceSet { shopMoney { amount currencyCode } } }
 pageInfo { hasNextPage endCursor }
}}'''


async def get_pages(domain, token, query, limit=10):
    nodes = []
    cursor = None
    has_more = False
    for _ in range(limit):
        data = await gql(domain, token, query, {'cursor': cursor})
        root = data.get('products') if 'products' in data else data.get('orders')
        if not root:
            raise HTTPException(502, 'Invalid Shopify response format')
        nodes.extend(root.get('nodes', []))
        page = root.get('pageInfo', {})
        has_more = bool(page.get('hasNextPage'))
        if not has_more:
            break
        cursor = page.get('endCursor')
        if not cursor:
            raise HTTPException(502, 'Incomplete Shopify pagination response')
    return nodes, has_more


@app.post('/shopify/sync')
async def shopify_sync(request: Request, csrf: str = Form(...), sess: Session = Depends(db)):
    user = must_user(request, sess)
    form_guard(request, csrf)
    sh = sess.scalar(select(Shop).where(Shop.user_id == user.id))
    if not sh:
        raise HTTPException(400, 'Connect a store first')
    token = await fresh_token(sh, sess)
    shopdata = await gql(sh.domain, token, SHOP_QUERY)
    shopinfo = shopdata.get('shop', {})
    currency = shopinfo.get('currencyCode')
    if not currency:
        raise HTTPException(502, 'Shopify did not provide store currency')
    products, products_more = await get_pages(sh.domain, token, PRODUCT_QUERY)
    orders, orders_more = await get_pages(sh.domain, token, ORDERS_QUERY)
    total = Decimal('0')
    count = 0
    per_day = defaultdict(lambda: Decimal('0'))
    earliest = time.time() - 60*24*60*60
    for o in orders:
        if o.get('cancelledAt') or o.get('displayFinancialStatus') not in ('PAID', 'PARTIALLY_REFUNDED'):
            continue
        try:
            ts = datetime.fromisoformat(o['processedAt'].replace('Z', '+00:00'))
            amount = o['currentTotalPriceSet']['shopMoney']['amount']
            money = Decimal(str(amount))
            if ts.timestamp() < earliest:
                continue
            total += money
            count += 1
            per_day[ts.strftime('%Y-%m-%d')] += money
        except (KeyError, ValueError, TypeError, InvalidOperation):
            continue
    row = sess.scalar(select(Snapshot).where(Snapshot.user_id == user.id)) or Snapshot(user_id=user.id)
    row.domain = sh.domain
    row.currency = currency
    row.shop_name = shopinfo.get('name', sh.domain)
    row.product_count = len(products)
    row.paid_order_count = count
    row.paid_order_value_minor = int(total * 100)
    row.paid_order_days = json.dumps([{'date': k, 'value': str(v)} for k, v in sorted(per_day.items())])
    row.products_json = json.dumps([{'title': p.get('title', ''), 'inventory': p.get('totalInventory'), 'status': p.get('status')} for p in products[:25]])
    row.orders_limited = int(orders_more)
    row.products_limited = int(products_more)
    row.synced_at = time.time()
    sess.add(row)
    sess.commit()
    return RedirectResponse('/dashboard?synced=1', 303)


@app.post('/ask')
def ask_ayo(request: Request, question: str = Form(...), csrf: str = Form(...), sess: Session = Depends(db)):
    """Actual read-tool style business answers over real synchronized aggregates.

    This intentionally uses deterministic calculations, NOT a pretend LLM.
    """
    user = must_user(request, sess)
    form_guard(request, csrf)
    snapshot = sess.scalar(select(Snapshot).where(Snapshot.user_id == user.id))
    if not snapshot:
        request.session['insight'] = 'Connect and synchronize Shopify first. Ayo never invents business answers.'
        return RedirectResponse('/dashboard#ask-ayo', 303)
    q = question.lower().strip()[:300]
    products = json.loads(snapshot.products_json)
    limited = bool(snapshot.orders_limited or snapshot.products_limited)
    caveat = ' Import is currently incomplete, so this answer covers only fetched records.' if limited else ''
    if any(word in q for word in ['sale', 'revenue', 'money', 'value', 'earn']):
        answer = f'The connected Shopify store returned {snapshot.paid_order_count} eligible paid orders over the available recent period, with current order totals of {snapshot.currency} {Decimal(snapshot.paid_order_value_minor)/100:,.2f}. This is recorded paid order value, not net profit or audited revenue.'
    elif any(word in q for word in ['stock', 'inventory', 'low', 'restock']):
        low = [p for p in products if p.get('inventory') is not None and p['inventory'] <= 5]
        if low:
            answer = 'Low stock among the imported product preview: ' + '; '.join(f"{p['title']} ({p['inventory']} units)" for p in low[:8]) + '. Confirm sales velocity and reorder constraints before purchasing.'
        else:
            answer = 'No inventory quantity of 5 or fewer appears among the first 25 imported products. This is not a guarantee that the full store has no stock risk.'
    elif any(word in q for word in ['product', 'catalog', 'item', 'sku']):
        answer = f'Shopify returned {snapshot.product_count} products in the last sync. Inventory and status fields are included where authorized. Ayo currently shows the first 25, not the complete product catalog.'
    elif any(word in q for word in ['sync', 'update', 'fresh', 'connect']):
        when = datetime.fromtimestamp(snapshot.synced_at, timezone.utc).strftime('%Y-%m-%d %H:%M UTC')
        answer = f'The most recent successful Shopify synchronization for {snapshot.domain} finished at {when}. The next import must be triggered manually in this alpha.'
    elif any(word in q for word in ['profit', 'margin', 'roas', 'ad spend', 'marketing']):
        answer = 'Ayo cannot calculate that accurately from the connected data yet. Shopify order totals and product inventory do not provide costs, advertising spend or proper attribution. Those integrations and cost records must be added before Ayo can make a trustworthy recommendation.'
    else:
        answer = 'I can answer questions about the actual synchronized paid order value, order count, product list, low stock or sync freshness. More capabilities require additional real data sources. This alpha uses deterministic data tools, not a generative AI model.'
    request.session['insight'] = answer + caveat
    return RedirectResponse('/dashboard#ask-ayo', 303)


@app.post('/shopify/disconnect')
def disconnect(request: Request, csrf: str = Form(...), sess: Session = Depends(db)):
    user = must_user(request, sess)
    form_guard(request, csrf)
    sh = sess.scalar(select(Shop).where(Shop.user_id == user.id))
    snap = sess.scalar(select(Snapshot).where(Snapshot.user_id == user.id))
    if sh:
        sess.delete(sh)
    if snap:
        sess.delete(snap)
    sess.commit()
    return RedirectResponse('/dashboard?disconnected=1', 303)


@app.post('/shopify/webhooks/{topic:path}')
async def shopify_webhook(topic: str, request: Request, sess: Session = Depends(db)):
    body = await request.body()
    if not webhook_valid(body, request.headers.get('X-Shopify-Hmac-Sha256', '')):
        raise HTTPException(401, 'Invalid webhook signature')
    # Topics must be configured on the Shopify app. Verified messages ONLY.
    allowed = {'app/uninstalled', 'shop/redact', 'customers/data_request', 'customers/redact'}
    if topic not in allowed:
        raise HTTPException(404)
    domain = request.headers.get('X-Shopify-Shop-Domain', '').lower()
    if topic in ('app/uninstalled', 'shop/redact'):
        try:
            domain = shop_domain(domain)
        except HTTPException:
            return {'ok': True}
        sh = sess.scalar(select(Shop).where(Shop.domain == domain))
        if sh:
            snap = sess.scalar(select(Snapshot).where(Snapshot.user_id == sh.user_id))
            if snap:
                sess.delete(snap)
            sess.delete(sh)
            sess.commit()
    # This MVP deliberately does not copy any customer personal records.
    # Compliance requests must be reviewed and logged for production operations.
    return {'ok': True}
